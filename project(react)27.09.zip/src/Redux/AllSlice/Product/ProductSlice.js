import { createAsyncThunk,createSlice } from "@reduxjs/toolkit";
import axios from "axios";
let api_url="http://localhost:4000/product"

export const fetchProduct = createAsyncThunk("product/fetchProducts", async () => {
    const res = await axios.get(api_url);
    return res?.data;
  });
  
  export const selectProduct = createAsyncThunk(
    "product/selectProduct",
    async (id) => {
      console.log("received id",id);
      const res = await axios.get(`${api_url}/${id}`);
      console.log("Fetched data in slice: ",res.data);
      return res?.data;
    }
  );  
  export const addToWishlist = createAsyncThunk(
    "product/addToWishlist",
    async (product) => {
     
      return product;
    }
  );

  export const removeFromWishlist = createAsyncThunk(
    "product/removeFromWishlist",
    async (productId) => {
     
      return productId;
    }
  );
  const initial_value = {
    isLoading: false,
    products: [],
    selectedProduct: "",
    error: null,
    wishlist: [],
    
  };
  export const productSlice = createSlice({
    name: "products",
    initialState: initial_value,
    reducers: {},
    extraReducers: (builder) => {
      builder.addCase(fetchProduct.pending, (state) => {
          state.isLoading = true;
          state.error = null;
        })
        builder.addCase(fetchProduct.fulfilled, (state, action) => {
          state.isLoading = false;
          state.products = action.payload;
        
        })
        builder.addCase(fetchProduct.rejected, (state, action) => {
          state.isLoading = false;
          state.error = action.error.message;
        })
        builder.addCase(selectProduct.pending, (state) => {
          state.isLoading = true;
          state.error = null;
        })
        builder.addCase(selectProduct.fulfilled, (state, action) => {
          state.isLoading = false;
          state.selectedProduct = action.payload;
          state.id=action.payload
          console.log(state.id)
        })
        builder.addCase(selectProduct.rejected, (state, action) => {
          state.isLoading = false;
          state.error = action.error.message;
        });
        builder.addCase(addToWishlist.fulfilled, (state, action) => {
          state.wishlist.push(action.payload);
        })
        builder.addCase(removeFromWishlist.fulfilled, (state, action) => {
          state.wishlist = state.wishlist.filter((product) => product.id !== action.payload);
        });
    },
  });
  export default productSlice.reducer