import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { CircularProgress, Container, Paper, Typography, Avatar,List,
  ListItem,
  ListItemIcon,
  ListItemText,} from '@mui/material';
import { profile } from '../../../Redux/AllSlice/AuthSlice/AuthSlice';
import './Profile.css'

const ProfilePage = () => {
  let base_url = 'https://wtsacademy.dedicateddevelopers.us/';
  let folder_path = 'uploads/user/profile_pic/';
  const dispatch = useDispatch();
  const { email, isLoading, first_name, last_name, error, profile_pic } = useSelector((state) => state.auth);
  const img_url = base_url + folder_path + profile_pic;

  useEffect(() => {
    dispatch(profile());
  }, [dispatch]);
  const menuItems = [
    { text: 'Messages', icon: 'message' },
    { text: 'Events', icon: 'event' },
    { text: 'Account Settings', icon: 'settings' },
  ];

  return (
    <Container className='profile-pic'>
      <Paper style={{ padding: '16px', display: 'flex', flexDirection: 'column', alignItems: 'center',marginTop: '50px' }}>
        <Avatar alt={first_name} src={img_url} sx={{ width: 100, height: 100 }} />
        <Typography variant="h4" gutterBottom>
          Profile
        </Typography>
        {isLoading ? (
          <CircularProgress />
        ) : error ? (
          <Typography variant="body1"> {error.message}</Typography>
        ) : (
          <div>
            <Typography variant="body1">First Name: {first_name}</Typography>
            <Typography variant="body1">Last Name: {last_name}</Typography>
            <Typography variant="body1">Email: {email}</Typography>
          </div>
        )}
      </Paper>
      <Paper className='menu-bar'>
        <List>
          {menuItems.map((item, index) => (
            <ListItem button key={index} className='menu-item'>
              <ListItemIcon className='menu-icon'>
                <i className={`material-icons`}>{item.icon}</i>
              </ListItemIcon>
              <ListItemText primary={item.text} className='menu-text' />
            </ListItem>
          ))}
        </List>
      </Paper>
    </Container>
  );
};

export default ProfilePage;