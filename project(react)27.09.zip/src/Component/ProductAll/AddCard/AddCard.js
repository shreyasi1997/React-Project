import React from 'react';
import { Box, List, ListItem, ListItemText } from '@mui/material';

const EmptyListWithPicture = () => {
  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      height="500px" 
    >
      <List>
        <ListItem>
          <img
            src="assets/empty-shopping-bag.png"
            alt="Empty List"
            style={{ width: '100px', height: '100px' }}
          />
        </ListItem>
        <ListItem>
          <ListItemText primary="No items to display." />
        </ListItem>
      </List>
    </Box>
  );
};

export default EmptyListWithPicture;


