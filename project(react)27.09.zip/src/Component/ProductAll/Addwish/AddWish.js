import React from 'react';
import { Box, List, ListItem, ListItemText, Button } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { removeFromWishlist } from '../../../Redux/AllSlice/Product/ProductSlice';
import './Addwish.css'

const Wishlist = () => {
  const wishlist = useSelector((state) => state.products.wishlist) || [];
  const dispatch = useDispatch();

  const handleRemoveFromWishlist = (productId) => {
    dispatch(removeFromWishlist(productId));
  };

  return (
    <div className='wish'>
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        height="500px"
      >
        {wishlist.length === 0 ? (
          <List>
            <ListItem>
              <img
                src="assets/empty-wish.gif"
                alt="Empty Wishlist"
                style={{ width: '100px', height: '200px' }}
              />
            </ListItem>
            <ListItem>
              <ListItemText primary="Wishlist is empty." />
            </ListItem>
          </List>
        ) : (
          <div className="wishlist-items">
            {wishlist.map((product) => (
              <div key={product.id}>
                <div className="wishlist-image">
                  <img
                    src={product.image_url}
                    alt={product.name}
                  />
                </div>
                <p>{product.name}</p>
                <p>₹{product.price}</p>
                <Button
                  variant="contained"
                  color="error"
                  onClick={() => handleRemoveFromWishlist(product.id)}
                >
                  Remove
                </Button>
              </div>
            ))}
          </div>
        )}
      </Box>
    </div>
  );
};

export default Wishlist;