import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectProduct, addToWishlist, addToCart } from '../../../Redux/AllSlice/Product/ProductSlice';
import { Link, useParams } from 'react-router-dom';
import { Typography, Card, CardContent, Container, Grid, Box } from '@mui/material';
import { IconButton } from '@mui/material';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';
import StarIcon from '@mui/icons-material/Star';
import { Button } from '@mui/material';
import './Single.css'; // You can update the import for your custom CSS

const SingleProduct = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { selectedProduct } = useSelector((state) => state.products);

  useEffect(() => {
    dispatch(selectProduct(id))
      .unwrap()
      .then((res) => {
        console.log("Single: ", res);
      })
      .catch((err) => {
        console.log("Error in single: ", err);
      });
  }, [dispatch, id]);

  const handleAddToCart = () => {
    dispatch(addToCart(selectedProduct));
    console.log("Added to Cart:", selectedProduct.name);
  };

  const handleAddToWishlist = () => {
    dispatch(addToWishlist(selectedProduct));
    console.log("Added to Wishlist:", selectedProduct.name);
  };

  const handleBuyNow = () => {
    console.log("Buy Now:", selectedProduct.name);
  };

  const [isImageHovered, setIsImageHovered] = useState(false);

  return (
    <Container>
      <Box mt={3} mb={3}>
        <Typography variant="h3">Product Details</Typography>
      </Box>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={4}>
          <Card elevation={3}>
            <CardContent>
              <div
                className={`product-image-container ${isImageHovered ? 'zoomed' : ''}`}
                onMouseEnter={() => setIsImageHovered(true)}
                onMouseLeave={() => setIsImageHovered(false)}
              >
                <img
                  src={selectedProduct.image_url}
                  alt={selectedProduct.name}
                  className="product-image" // Modify the class name for the image
                />
              </div>
            </CardContent>
            <Box p={2}>
              <Link to="/payment">
                <Button
                  variant="contained"
                  color="success"
                  fullWidth
                  onClick={handleBuyNow}
                >
                  Buy Now
                </Button>
              </Link>
              <Box mt={1}>
                <Link to="/addwish">
                  <IconButton
                    color="secondary"
                    aria-label="Add to Wishlist"
                    onClick={handleAddToWishlist}
                  >
                    <Typography>Add to wishlist</Typography>
                    <FavoriteIcon />
                  </IconButton>
                </Link>
              </Box>
              <Box mt={1}>
                <Link to="/addcard">
                  <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={handleAddToCart}
                    startIcon={<AddShoppingCartIcon />}
                  >
                    Add to Cart
                  </Button>
                </Link>
              </Box>
            </Box>
          </Card>
        </Grid>
        <Grid item xs={12} sm={8}>
          <Card elevation={3}>
            <CardContent>
              <Typography variant="h4" gutterBottom>
                {selectedProduct.name}
              </Typography>
              <Typography variant="subtitle1" color="textSecondary">
                {selectedProduct.brand}
              </Typography>
              <Typography variant="subtitle2" color="textSecondary">
                Category: {selectedProduct.category}
              </Typography>
              <Typography variant="subtitle2" color="textSecondary">
                Gender: {selectedProduct.gender}
              </Typography>
              <Typography variant="subtitle2" color="textSecondary">
                Weight: {selectedProduct.weight}
              </Typography>
              <Typography variant="subtitle2" color="textSecondary">
                Quantity: {selectedProduct.quantity}
              </Typography>
              <Typography variant="subtitle2" color="textSecondary">
                Rating: {selectedProduct.rating}
                <StarIcon color="secondary" />
              </Typography>
              <Typography variant="h5" mt={2}>
                Price: ₹{selectedProduct.price}
              </Typography>
              <Typography variant="h6" color="error">
                New Price: ₹{selectedProduct.newPrice}
              </Typography>
              <Typography variant="body1" mt={2}>
                {selectedProduct.description}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default SingleProduct;