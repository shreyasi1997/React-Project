import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { signin } from '../../../Redux/AllSlice/AuthSlice/AuthSlice';
import { useNavigate } from 'react-router-dom';
import './Login.css';
import {
  TextField,
  Button,
  Container,
  Typography,
  CssBaseline,
  Avatar,
  FormControl,
  InputLabel,
  InputAdornment,
  IconButton,
  OutlinedInput,
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';

const Login = () => {
  const dispatch = useDispatch();
  const [state, setState] = useState({
    email: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();

  const changeHandler = (e) => {
    e.persist();
    const { name, value } = e.target;
    setState({ ...state, [name]: value });
  };

  const togglePasswordVisibility = () => {
    setShowPassword((prevShowPassword) => !prevShowPassword);
  };

  const submitHandler = (e) => {
    e.preventDefault();
    console.log('Collected from Login', state);
    let formData = new FormData();
    formData.append('email', state.email);
    formData.append('password', state.password);
    dispatch(signin(formData))
      .then((res) => {
        console.log('status now:', res.payload.status);
        if (res.payload.status === 200) navigate('/profile', { replace: true });
        else document.getElementById('loginForm').reset();
      })
      .catch((err) => {
        document.getElementById('loginForm').reset();
      });
  };

  return (
    <div className="login">
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
       <Avatar style={{ marginTop: '50px' }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Sign in
          </Typography>
          <form id="loginForm" onSubmit={submitHandler} style={{ width: '100%', marginTop: '1rem', marginTop: '50px',backgroundColor: "#f5f5f5'" }}>
            <FormControl variant="outlined" fullWidth>
              <InputLabel htmlFor="outlined-email">Enter Your Email</InputLabel>
              <OutlinedInput
                id="outlined-email"
                type="email"
                name="email"
                onChange={changeHandler}
                value={state.email}
                label="Enter Your Email"
              />
            </FormControl>

            <FormControl variant="outlined" fullWidth>
              <InputLabel htmlFor="outlined-password">Enter Your Password</InputLabel>
              <OutlinedInput
                id="outlined-password"
                type={showPassword ? 'text' : 'password'} 
                name="password"
                onChange={changeHandler}
                value={state.password}
                label="Enter Your Password"
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton edge="end" onClick={togglePasswordVisibility}>
                      {showPassword ? <Visibility /> : <VisibilityOff />}
                    </IconButton>
                  </InputAdornment>
                }
              />
            </FormControl>

            <Button type="submit" variant="contained" color="primary" fullWidth>
              Login
            </Button>
          </form>
        </div>
      </Container>
    </div>
  );
};

export default Login;