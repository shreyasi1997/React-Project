import React from 'react'

export const PNF = () => {
  return (
    <div>
         <img src="assets/404-error.gif" alt="Banner Image" width="50%" />
    </div>
  )
}
