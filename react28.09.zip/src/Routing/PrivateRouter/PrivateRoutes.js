import React from 'react'
import { Navigate,Outlet } from 'react-router-dom'
const PrivateRoutes = () => {
  return (
    <div>
         const isAuth=window.sessionStorage.getItem("token");
    console.log("receive ",isAuth)
  return  isAuth ?<Outlet/>: <Navigate to ="/sing-in" />
    </div>
  )
}

export default PrivateRoutes