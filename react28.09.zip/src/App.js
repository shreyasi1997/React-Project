import './App.css';
import RootRouting from './Routing/RootRouting';

function App() {
  return (
    <div className="App">
   <RootRouting/>
    </div>
  );
}
export default App;
