import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';

const PrivateRoutes = () => {
  const isAuth = window.sessionStorage.getItem('token');
  console.log('receive ', isAuth);

  return isAuth ? <Outlet /> : <Navigate to="/login" />;
};

export default PrivateRoutes;