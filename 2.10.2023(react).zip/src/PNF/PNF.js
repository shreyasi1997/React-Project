import React from 'react'
import './pnf.css'

export const PNF = () => {
  return (
    <div className='pnf-full'>
         <img src="assets/404-error.gif" alt="Banner Image" width="50%" />
    </div>
  )
}
