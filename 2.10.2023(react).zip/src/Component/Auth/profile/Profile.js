import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  CircularProgress,
  Container,
  Paper,
  Typography,
  Avatar,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from '@mui/material';
import { profile } from '../../../Redux/AllSlice/AuthSlice/AuthSlice';
import './Profile.css';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';

const ProfilePage = () => {
  const dispatch = useDispatch();
  const { email, isLoading, first_name, last_name, error, profile_pic, bio, address, phone } =
    useSelector((state) => state.auth);

  useEffect(() => {
    dispatch(profile());
  }, [dispatch]);

  const profileImageUrl = profile_pic
    ? `https://wtsacademy.dedicateddevelopers.us/uploads/user/profile_pic/${profile_pic}`
    : 'placeholder_image_url.jpg'; // Replace with a default placeholder image URL

  const menuItems = [
    { text: 'Messages', icon: 'message' },
    { text: 'Events', icon: 'event' },
    { text: 'Account Settings', icon: 'settings' },
    { text: 'Your Order', icon: <ShoppingCartIcon /> },
    {
      text: 'Coupon Code',
      icon: 'local_offer',}
  ];

  return (
    <div className='profile-all'>
    <Container className="profile-container">
      <Paper elevation={3} className="profile-paper">
        <Avatar alt={first_name} src={profileImageUrl} sx={{ width: 150, height: 150 }} />
        <Typography variant="h4" gutterBottom className="profile-heading">
          {first_name} {last_name}
        </Typography>
        {isLoading ? (
          <CircularProgress />
        ) : error ? (
          <Typography variant="body1" className="error-message">
            {error.message}
          </Typography>
        ) : (
          <div className="profile-details">
            <Typography variant="body1">Email: {email}</Typography>
           
           
          </div>
        )}
      </Paper>
      <Paper elevation={3} className="menu-bar">
        <List>
          {menuItems.map((item, index) => (
            <ListItem button key={index} className="menu-item">
              <ListItemIcon className="menu-icon">
                <i className={`material-icons`}>{item.icon}</i>
              </ListItemIcon>
              <ListItemText primary={item.text} className="menu-text" />
            </ListItem>
          ))}
        </List>
        <Divider />
     
      </Paper>
    </Container>
    </div>
  );
};

export default ProfilePage;